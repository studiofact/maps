$(document).ready(function() {

        //������ ����� � ������������

        $('.map').maphilight({fade: false});

        var myMap;
        ymaps.ready(InitMap);

        function SelectPoint(myMap, point) {
            myMap.setZoom(3);
            myMap.panTo(point, {callback: function() {
                myMap.setZoom(16);
            }});
        }

        function InitMap() {
            myMap = new ymaps.Map("ya_maps_container", {
                center: [65.87, 105.66],
                zoom: 3
            });

            myMap.controls.add('zoomControl');

            // ������������ �����

            $(".show_in_map").each(function() {
                var coords = $(this).data("coords");
                if(coords) {
                    var myPlacemark = new ymaps.Placemark(coords);
                    myPlacemark.events.add("click", function(arg) {
                        var object = arg.get('target');

                        myMap.panTo(coords, {callback: function() {
                            myMap.setZoom(16);
                        }});
                    })
                    myMap.geoObjects.add(myPlacemark);
                }
            });

        }

        // ��������� � ����� �� �����

        $(".show_in_map").click(function() {
            SelectPoint(myMap, $(this).data("coords"));
            return false;
        });

		$(".head_menu.interactive li a").click(function() {

			$(this).parents(".head_menu.interactive").find(".active").removeClass("active");
			$(this).addClass("active");

			var type = $(this).data("type");
		   if(type != "all") {
			$(".shop_one[data-type!='"+type+"']").hide();
			$(".shop_one[data-type='"+type+"']").show();
		   } else {
			$(".shop_one[data-type]").show();
		   }
			return false;
		});
		
		

		
})
