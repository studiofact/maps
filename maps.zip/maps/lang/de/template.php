<?
$MESS["CATALOG_ADD"] = "In Warenkorb";
$MESS["CATALOG_COMPARE"] = "Vergleichen";
$MESS["CT_BCS_TPL_ELEMENT_DELETE_CONFIRM"] = "Alle mit diesem Eintrag verbundenen Informationen gehen verloren. Wollen Sie Fortfahren?";
$MESS["CT_BCS_TPL_MESS_BTN_BUY"] = "Kaufen";
$MESS["CT_BCS_TPL_MESS_PRODUCT_NOT_AVAILABLE"] = "nicht auf Lager";
$MESS["CT_BCS_TPL_MESS_BTN_DETAIL"] = "Mehr";
$MESS["CT_BCS_TPL_MESS_BTN_SUBSCRIBE"] = "Benachrichtigen wenn wieder auf Lager";
$MESS["CT_BCS_TPL_MESS_PRICE_FROM"] = "ab";
$MESS["CATALOG_SET_BUTTON_BUY"] = "Zum Warenkorb";
$MESS["ADD_TO_BASKET_OK"] = "Produkt wurde zum Warenkorb hinzugef�gt";
?>