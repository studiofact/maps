<?
$MESS["CATALOG_ADD"] = "Add to cart";
$MESS["CATALOG_COMPARE"] = "Compare";
$MESS["CT_BCS_TPL_ELEMENT_DELETE_CONFIRM"] = "All the information linked to this record will be deleted. Continue anyway?";
$MESS["CT_BCS_TPL_MESS_BTN_BUY"] = "Buy";
$MESS["CT_BCS_TPL_MESS_PRODUCT_NOT_AVAILABLE"] = "not available from stock";
$MESS["CT_BCS_TPL_MESS_BTN_DETAIL"] = "More";
$MESS["CT_BCS_TPL_MESS_BTN_SUBSCRIBE"] = "Notify when back in stock";
$MESS["CT_BCS_TPL_MESS_PRICE_FROM"] = "from";
$MESS["CATALOG_SET_BUTTON_BUY"] = "Go to shopping cart";
$MESS["ADD_TO_BASKET_OK"] = "Item added to cart";
?>